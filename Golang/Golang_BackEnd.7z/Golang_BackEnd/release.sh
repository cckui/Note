#!/bin/bash

MYPWD=${PWD} 
cd $MYPWD
mkdir $MYPWD/_Release

chmod +x run.sh stop.sh install.sh

echo "copy file..."
cp docker-compose.yaml run.sh stop.sh install.sh config.json $MYPWD/_Release/
cp -R _conf/ $MYPWD/_Release/
sudo cp -R _mysql/ $MYPWD/_Release/

echo "export Docker Image..."
cd $MYPWD/_Release/
docker save -o agv_web.tar agv_web:latest
docker save -o mysql.tar mysql:8.0
docker save -o redis.tar redis:5.0-alpine






