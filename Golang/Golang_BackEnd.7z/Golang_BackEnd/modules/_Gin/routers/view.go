package route

import (
	web "project/modules/_Gin/controllers/view"
)

func (r *Router) InitWeb() {
	r.Routers = r.Root.Group("/")

	r.Routers.GET("/logout", web.IndexLogout)
	r.Routers.GET("/", web.IndexSample)
	r.Routers.GET("/dashboard", web.RedirectIndexSample)
	r.Routers.Use(ginAuthBasic()) // 加入這行後以下都需驗證，以上不需驗證
	r.Routers.POST("/login", web.IndexLogin)
	r.Routers.GET("/login", web.IndexLogin)
	// r.Routers.POST("/test/:id", api.xxx)
}
