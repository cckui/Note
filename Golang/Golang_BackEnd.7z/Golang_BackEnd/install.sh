#!/bin/bash

echo stop and removing previous containers and images...
docker-compose down
docker stop agv_web
docker rm agv_web
docker rmi agv_web

docker stop mysql
docker rm mysql
docker rmi mysql

docker stop redis
docker rm redis
docker rmi redis

echo Installing images...
docker load < agv_web.tar
docker load < mysql.tar
docker load < redis.tar
